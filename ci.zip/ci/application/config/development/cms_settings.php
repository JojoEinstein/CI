$config['cms_title'] = 'CI App';
$config['cms_dev'] = 'raizakurniawan@gmail.com';